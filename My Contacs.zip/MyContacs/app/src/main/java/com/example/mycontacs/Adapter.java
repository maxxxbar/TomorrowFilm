package com.example.mycontacs;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.AdapterViewHolder> {

    private List<Contact> contact = new ArrayList<>();

    private OnItemClick onItemClick;

    public interface OnItemClick {
        void onItemClick(int position);
    }

    public void setOnItemClick(OnItemClick onItemClick) {
        this.onItemClick = onItemClick;
    }

    @NonNull
    @Override
    public AdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.contact_item, parent, false);
        return new AdapterViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterViewHolder holder, int position) {
        Contact contactItem = contact.get(position);

        holder.textViewFirstName.setText(contactItem.getFirstName());
        holder.textViewSecondName.setText(contactItem.getSecondName());
        holder.textViewEmail.setText(contactItem.getEmail());
        holder.textViewPhone.setText(contactItem.getPhone());

    }

    @Override
    public int getItemCount() {
        return contact.size();
    }

    public void setContact(List<Contact> contact) {
        this.contact = contact;
    }

    class AdapterViewHolder extends RecyclerView.ViewHolder {
        private TextView textViewFirstName;
        private TextView textViewSecondName;
        private TextView textViewEmail;
        private TextView textViewPhone;

        public AdapterViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewFirstName = itemView.findViewById(R.id.textViewOneItemFirstName);
            textViewSecondName = itemView.findViewById(R.id.textViewOneItemSecondName);
            textViewEmail = itemView.findViewById(R.id.textViewOneItemEmail);
            textViewPhone = itemView.findViewById(R.id.textViewOneItemPhone);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onItemClick != null) {
                        onItemClick.onItemClick(getAdapterPosition());
                    }
                }
            });
        }
    }


}
