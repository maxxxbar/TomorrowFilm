package com.example.mycontacs;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Maybe;
import io.reactivex.Observable;
import io.reactivex.Single;

@Dao
public interface ContactDatabaseDAO {

/*    @Insert
    Maybe<Contact> addContact(Contact contact);*/

    @Update
    Completable updateContact(Contact contact);

    @Delete
    Completable deleteContact(Contact contact);

    @Query("SELECT * FROM contacts")
    Observable<List<Contact>> getAllContacts();

    @Query("SELECT * FROM contacts WHERE id == :idContact")
    Single<Contact> getOneContact(long idContact);
}
