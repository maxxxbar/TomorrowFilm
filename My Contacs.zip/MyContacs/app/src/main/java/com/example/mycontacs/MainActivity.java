package com.example.mycontacs;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerViewContact);
        final List<Contact> contacts = new ArrayList<>();

        for (int i = 0; i < 50; i++) {
            Contact contact = new Contact("Name #" + i, "Second Name #" + i, "Email #" + i, "Phone #" + i);
            contacts.add(contact);
        }
        final Adapter adapter = new Adapter();
        adapter.setContact(contacts);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
        adapter.setOnItemClick(new Adapter.OnItemClick() {
            @Override
            public void onItemClick(int position) {
                Toast.makeText(MainActivity.this, "Элемент номер " + position, Toast.LENGTH_SHORT).show();
                oneItem(false, contacts.get(position), position);
            }
        });

    }

    public void oneItem(boolean isUpdate, Contact contact, int position) {
        LayoutInflater inflater = LayoutInflater.from(getApplicationContext());
        View view = inflater.inflate(R.layout.contact_item, null);

        AlertDialog.Builder builder = new AlertDialog.Builder(getApplicationContext());
        builder.setView(view);

        final TextView textViewOneItemFirstName = findViewById(R.id.textViewOneItemFirstName);
        final TextView textViewOneItemSecondName = findViewById(R.id.textViewOneItemSecondName);
        final TextView textViewOneItemEmail = findViewById(R.id.textViewOneItemEmail);
        final TextView textViewOneItemPhone = findViewById(R.id.textViewOneItemPhone);

        textViewOneItemFirstName.setText(contact.getFirstName());
        textViewOneItemSecondName.setText(contact.getSecondName());
        textViewOneItemEmail.setText(contact.getEmail());
        textViewOneItemPhone.setText(contact.getPhone());

        builder
                .setCancelable(false)
                .setTitle("Окно")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                })
                .setNegativeButton("HE OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}